/****************************************************************************
** Meta object code from reading C++ file 'mesh2mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../src/mesh2mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mesh2mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Mesh2MainWindow_t {
    QByteArrayData data[63];
    char stringdata0[742];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Mesh2MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Mesh2MainWindow_t qt_meta_stringdata_Mesh2MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 15), // "Mesh2MainWindow"
QT_MOC_LITERAL(1, 16, 4), // "open"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 8), // "openMesh"
QT_MOC_LITERAL(4, 31, 14), // "createFunction"
QT_MOC_LITERAL(5, 46, 4), // "name"
QT_MOC_LITERAL(6, 51, 14), // "createPSurface"
QT_MOC_LITERAL(7, 66, 11), // "setFileType"
QT_MOC_LITERAL(8, 78, 15), // "pickCoordSystem"
QT_MOC_LITERAL(9, 94, 8), // "QAction*"
QT_MOC_LITERAL(10, 103, 13), // "pickPlotStyle"
QT_MOC_LITERAL(11, 117, 14), // "pickFloorStyle"
QT_MOC_LITERAL(12, 132, 13), // "pickAxesColor"
QT_MOC_LITERAL(13, 146, 11), // "pickBgColor"
QT_MOC_LITERAL(14, 158, 13), // "pickMeshColor"
QT_MOC_LITERAL(15, 172, 15), // "pickNumberColor"
QT_MOC_LITERAL(16, 188, 14), // "pickLabelColor"
QT_MOC_LITERAL(17, 203, 14), // "pickTitleColor"
QT_MOC_LITERAL(18, 218, 13), // "pickDataColor"
QT_MOC_LITERAL(19, 232, 12), // "pickLighting"
QT_MOC_LITERAL(20, 245, 11), // "resetColors"
QT_MOC_LITERAL(21, 257, 14), // "pickNumberFont"
QT_MOC_LITERAL(22, 272, 13), // "pickLabelFont"
QT_MOC_LITERAL(23, 286, 13), // "pickTitleFont"
QT_MOC_LITERAL(24, 300, 10), // "resetFonts"
QT_MOC_LITERAL(25, 311, 15), // "setStandardView"
QT_MOC_LITERAL(26, 327, 9), // "dumpImage"
QT_MOC_LITERAL(27, 337, 15), // "toggleAnimation"
QT_MOC_LITERAL(28, 353, 20), // "toggleProjectionMode"
QT_MOC_LITERAL(29, 374, 17), // "toggleColorLegend"
QT_MOC_LITERAL(30, 392, 15), // "toggleAutoScale"
QT_MOC_LITERAL(31, 408, 3), // "val"
QT_MOC_LITERAL(32, 412, 12), // "toggleShader"
QT_MOC_LITERAL(33, 425, 6), // "rotate"
QT_MOC_LITERAL(34, 432, 16), // "setPolygonOffset"
QT_MOC_LITERAL(35, 449, 10), // "showRotate"
QT_MOC_LITERAL(36, 460, 1), // "x"
QT_MOC_LITERAL(37, 462, 1), // "y"
QT_MOC_LITERAL(38, 464, 1), // "z"
QT_MOC_LITERAL(39, 466, 9), // "showShift"
QT_MOC_LITERAL(40, 476, 9), // "showScale"
QT_MOC_LITERAL(41, 486, 8), // "showZoom"
QT_MOC_LITERAL(42, 495, 11), // "showNormals"
QT_MOC_LITERAL(43, 507, 16), // "setNormalQuality"
QT_MOC_LITERAL(44, 524, 15), // "setNormalLength"
QT_MOC_LITERAL(45, 540, 12), // "openColorMap"
QT_MOC_LITERAL(46, 553, 19), // "Qwt3D::ColorVector&"
QT_MOC_LITERAL(47, 573, 2), // "cv"
QT_MOC_LITERAL(48, 576, 5), // "fname"
QT_MOC_LITERAL(49, 582, 15), // "adaptDataColors"
QT_MOC_LITERAL(50, 598, 17), // "updateColorLegend"
QT_MOC_LITERAL(51, 616, 6), // "majors"
QT_MOC_LITERAL(52, 623, 6), // "minors"
QT_MOC_LITERAL(53, 630, 11), // "setLeftGrid"
QT_MOC_LITERAL(54, 642, 1), // "b"
QT_MOC_LITERAL(55, 644, 12), // "setRightGrid"
QT_MOC_LITERAL(56, 657, 11), // "setCeilGrid"
QT_MOC_LITERAL(57, 669, 12), // "setFloorGrid"
QT_MOC_LITERAL(58, 682, 12), // "setFrontGrid"
QT_MOC_LITERAL(59, 695, 11), // "setBackGrid"
QT_MOC_LITERAL(60, 707, 7), // "setGrid"
QT_MOC_LITERAL(61, 715, 11), // "Qwt3D::SIDE"
QT_MOC_LITERAL(62, 727, 14) // "enableLighting"

    },
    "Mesh2MainWindow\0open\0\0openMesh\0"
    "createFunction\0name\0createPSurface\0"
    "setFileType\0pickCoordSystem\0QAction*\0"
    "pickPlotStyle\0pickFloorStyle\0pickAxesColor\0"
    "pickBgColor\0pickMeshColor\0pickNumberColor\0"
    "pickLabelColor\0pickTitleColor\0"
    "pickDataColor\0pickLighting\0resetColors\0"
    "pickNumberFont\0pickLabelFont\0pickTitleFont\0"
    "resetFonts\0setStandardView\0dumpImage\0"
    "toggleAnimation\0toggleProjectionMode\0"
    "toggleColorLegend\0toggleAutoScale\0val\0"
    "toggleShader\0rotate\0setPolygonOffset\0"
    "showRotate\0x\0y\0z\0showShift\0showScale\0"
    "showZoom\0showNormals\0setNormalQuality\0"
    "setNormalLength\0openColorMap\0"
    "Qwt3D::ColorVector&\0cv\0fname\0"
    "adaptDataColors\0updateColorLegend\0"
    "majors\0minors\0setLeftGrid\0b\0setRightGrid\0"
    "setCeilGrid\0setFloorGrid\0setFrontGrid\0"
    "setBackGrid\0setGrid\0Qwt3D::SIDE\0"
    "enableLighting"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Mesh2MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      48,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  254,    2, 0x0a /* Public */,
       3,    0,  255,    2, 0x0a /* Public */,
       4,    1,  256,    2, 0x0a /* Public */,
       6,    1,  259,    2, 0x0a /* Public */,
       7,    1,  262,    2, 0x0a /* Public */,
       8,    1,  265,    2, 0x0a /* Public */,
      10,    1,  268,    2, 0x0a /* Public */,
      11,    1,  271,    2, 0x0a /* Public */,
      12,    0,  274,    2, 0x0a /* Public */,
      13,    0,  275,    2, 0x0a /* Public */,
      14,    0,  276,    2, 0x0a /* Public */,
      15,    0,  277,    2, 0x0a /* Public */,
      16,    0,  278,    2, 0x0a /* Public */,
      17,    0,  279,    2, 0x0a /* Public */,
      18,    0,  280,    2, 0x0a /* Public */,
      19,    0,  281,    2, 0x0a /* Public */,
      20,    0,  282,    2, 0x0a /* Public */,
      21,    0,  283,    2, 0x0a /* Public */,
      22,    0,  284,    2, 0x0a /* Public */,
      23,    0,  285,    2, 0x0a /* Public */,
      24,    0,  286,    2, 0x0a /* Public */,
      25,    0,  287,    2, 0x0a /* Public */,
      26,    0,  288,    2, 0x0a /* Public */,
      27,    1,  289,    2, 0x0a /* Public */,
      28,    1,  292,    2, 0x0a /* Public */,
      29,    1,  295,    2, 0x0a /* Public */,
      30,    1,  298,    2, 0x0a /* Public */,
      32,    1,  301,    2, 0x0a /* Public */,
      33,    0,  304,    2, 0x0a /* Public */,
      34,    1,  305,    2, 0x0a /* Public */,
      35,    3,  308,    2, 0x0a /* Public */,
      39,    2,  315,    2, 0x0a /* Public */,
      40,    3,  320,    2, 0x0a /* Public */,
      41,    1,  327,    2, 0x0a /* Public */,
      42,    1,  330,    2, 0x0a /* Public */,
      43,    1,  333,    2, 0x0a /* Public */,
      44,    1,  336,    2, 0x0a /* Public */,
      45,    2,  339,    2, 0x0a /* Public */,
      49,    1,  344,    2, 0x0a /* Public */,
      50,    2,  347,    2, 0x0a /* Public */,
      53,    1,  352,    2, 0x0a /* Public */,
      55,    1,  355,    2, 0x0a /* Public */,
      56,    1,  358,    2, 0x0a /* Public */,
      57,    1,  361,    2, 0x0a /* Public */,
      58,    1,  364,    2, 0x0a /* Public */,
      59,    1,  367,    2, 0x0a /* Public */,
      60,    2,  370,    2, 0x0a /* Public */,
      62,    1,  375,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,   36,   37,   38,
    QMetaType::Void, QMetaType::Double, QMetaType::Double,   36,   37,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,   36,   37,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Bool, 0x80000000 | 46, QMetaType::QString,   47,   48,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   51,   52,
    QMetaType::Void, QMetaType::Bool,   54,
    QMetaType::Void, QMetaType::Bool,   54,
    QMetaType::Void, QMetaType::Bool,   54,
    QMetaType::Void, QMetaType::Bool,   54,
    QMetaType::Void, QMetaType::Bool,   54,
    QMetaType::Void, QMetaType::Bool,   54,
    QMetaType::Void, 0x80000000 | 61, QMetaType::Bool,    2,    2,
    QMetaType::Void, QMetaType::Bool,   31,

       0        // eod
};

void Mesh2MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Mesh2MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->open(); break;
        case 1: _t->openMesh(); break;
        case 2: _t->createFunction((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->createPSurface((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->setFileType((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->pickCoordSystem((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 6: _t->pickPlotStyle((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 7: _t->pickFloorStyle((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 8: _t->pickAxesColor(); break;
        case 9: _t->pickBgColor(); break;
        case 10: _t->pickMeshColor(); break;
        case 11: _t->pickNumberColor(); break;
        case 12: _t->pickLabelColor(); break;
        case 13: _t->pickTitleColor(); break;
        case 14: _t->pickDataColor(); break;
        case 15: _t->pickLighting(); break;
        case 16: _t->resetColors(); break;
        case 17: _t->pickNumberFont(); break;
        case 18: _t->pickLabelFont(); break;
        case 19: _t->pickTitleFont(); break;
        case 20: _t->resetFonts(); break;
        case 21: _t->setStandardView(); break;
        case 22: _t->dumpImage(); break;
        case 23: _t->toggleAnimation((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->toggleProjectionMode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->toggleColorLegend((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->toggleAutoScale((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->toggleShader((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->rotate(); break;
        case 29: _t->setPolygonOffset((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->showRotate((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 31: _t->showShift((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 32: _t->showScale((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 33: _t->showZoom((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 34: _t->showNormals((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 35: _t->setNormalQuality((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 36: _t->setNormalLength((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 37: { bool _r = _t->openColorMap((*reinterpret_cast< Qwt3D::ColorVector(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 38: _t->adaptDataColors((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 39: _t->updateColorLegend((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 40: _t->setLeftGrid((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 41: _t->setRightGrid((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 42: _t->setCeilGrid((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 43: _t->setFloorGrid((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 44: _t->setFrontGrid((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 45: _t->setBackGrid((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 46: _t->setGrid((*reinterpret_cast< Qwt3D::SIDE(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 47: _t->enableLighting((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Mesh2MainWindow::staticMetaObject = { {
    &DummyBase::staticMetaObject,
    qt_meta_stringdata_Mesh2MainWindow.data,
    qt_meta_data_Mesh2MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Mesh2MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Mesh2MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Mesh2MainWindow.stringdata0))
        return static_cast<void*>(this);
    return DummyBase::qt_metacast(_clname);
}

int Mesh2MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = DummyBase::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 48)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 48;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 48)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 48;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
