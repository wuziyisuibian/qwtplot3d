/********************************************************************************
** Form generated from reading UI file 'mesh2mainwindowbase4.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MESH2MAINWINDOWBASE4_H
#define UI_MESH2MAINWINDOWBASE4_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QHBoxLayout *hboxLayout;
    QHBoxLayout *hboxLayout1;
    QPushButton *normButton;
    QPushButton *lighting;
    QCheckBox *lightingswitch;
    QVBoxLayout *vboxLayout;
    QLabel *label_2;
    QSlider *offsSlider;
    QSpacerItem *spacerItem;
    QVBoxLayout *vboxLayout1;
    QLabel *label_3;
    QSlider *resSlider;
    QSpacerItem *spacerItem1;
    QHBoxLayout *hboxLayout2;
    QFrame *frame;
    QVBoxLayout *vboxLayout2;
    QVBoxLayout *vboxLayout3;
    QCheckBox *projection;
    QCheckBox *colorlegend;
    QCheckBox *autoscale;
    QCheckBox *mouseinput;
    QCheckBox *shader;
    QVBoxLayout *vboxLayout4;
    QLabel *label;
    QHBoxLayout *hboxLayout3;
    QSlider *normalsquality;
    QSlider *normalslength;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(6);
        gridLayout->setVerticalSpacing(6);
        gridLayout->setContentsMargins(8, 8, 8, 8);
        hboxLayout = new QHBoxLayout();
        hboxLayout->setSpacing(6);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        hboxLayout1 = new QHBoxLayout();
        hboxLayout1->setSpacing(6);
        hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
        hboxLayout1->setContentsMargins(0, 0, 0, 0);
        normButton = new QPushButton(centralWidget);
        normButton->setObjectName(QString::fromUtf8("normButton"));

        hboxLayout1->addWidget(normButton);

        lighting = new QPushButton(centralWidget);
        lighting->setObjectName(QString::fromUtf8("lighting"));
        lighting->setEnabled(false);

        hboxLayout1->addWidget(lighting);

        lightingswitch = new QCheckBox(centralWidget);
        lightingswitch->setObjectName(QString::fromUtf8("lightingswitch"));

        hboxLayout1->addWidget(lightingswitch);

        vboxLayout = new QVBoxLayout();
        vboxLayout->setSpacing(6);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        vboxLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        vboxLayout->addWidget(label_2);

        offsSlider = new QSlider(centralWidget);
        offsSlider->setObjectName(QString::fromUtf8("offsSlider"));
        offsSlider->setMaximum(30);
        offsSlider->setPageStep(5);
        offsSlider->setValue(5);
        offsSlider->setOrientation(Qt::Horizontal);
        offsSlider->setTickPosition(QSlider::TicksAbove);
        offsSlider->setTickInterval(2);

        vboxLayout->addWidget(offsSlider);


        hboxLayout1->addLayout(vboxLayout);

        spacerItem = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        hboxLayout1->addItem(spacerItem);

        vboxLayout1 = new QVBoxLayout();
        vboxLayout1->setSpacing(6);
        vboxLayout1->setObjectName(QString::fromUtf8("vboxLayout1"));
        vboxLayout1->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        vboxLayout1->addWidget(label_3);

        resSlider = new QSlider(centralWidget);
        resSlider->setObjectName(QString::fromUtf8("resSlider"));
        resSlider->setMinimum(1);
        resSlider->setMaximum(100);
        resSlider->setOrientation(Qt::Horizontal);
        resSlider->setTickPosition(QSlider::TicksAbove);
        resSlider->setTickInterval(5);

        vboxLayout1->addWidget(resSlider);


        hboxLayout1->addLayout(vboxLayout1);


        hboxLayout->addLayout(hboxLayout1);

        spacerItem1 = new QSpacerItem(71, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem1);


        gridLayout->addLayout(hboxLayout, 1, 0, 1, 1);

        hboxLayout2 = new QHBoxLayout();
        hboxLayout2->setSpacing(6);
        hboxLayout2->setObjectName(QString::fromUtf8("hboxLayout2"));
        hboxLayout2->setContentsMargins(0, 0, 0, 0);
        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Sunken);

        hboxLayout2->addWidget(frame);

        vboxLayout2 = new QVBoxLayout();
        vboxLayout2->setSpacing(6);
        vboxLayout2->setObjectName(QString::fromUtf8("vboxLayout2"));
        vboxLayout2->setContentsMargins(0, 0, 0, 0);
        vboxLayout3 = new QVBoxLayout();
        vboxLayout3->setSpacing(6);
        vboxLayout3->setObjectName(QString::fromUtf8("vboxLayout3"));
        vboxLayout3->setContentsMargins(0, 0, 0, 0);
        projection = new QCheckBox(centralWidget);
        projection->setObjectName(QString::fromUtf8("projection"));
        projection->setChecked(true);

        vboxLayout3->addWidget(projection);

        colorlegend = new QCheckBox(centralWidget);
        colorlegend->setObjectName(QString::fromUtf8("colorlegend"));

        vboxLayout3->addWidget(colorlegend);

        autoscale = new QCheckBox(centralWidget);
        autoscale->setObjectName(QString::fromUtf8("autoscale"));
        autoscale->setChecked(true);

        vboxLayout3->addWidget(autoscale);

        mouseinput = new QCheckBox(centralWidget);
        mouseinput->setObjectName(QString::fromUtf8("mouseinput"));
        mouseinput->setChecked(true);

        vboxLayout3->addWidget(mouseinput);

        shader = new QCheckBox(centralWidget);
        shader->setObjectName(QString::fromUtf8("shader"));
        shader->setChecked(true);

        vboxLayout3->addWidget(shader);


        vboxLayout2->addLayout(vboxLayout3);

        vboxLayout4 = new QVBoxLayout();
        vboxLayout4->setSpacing(6);
        vboxLayout4->setObjectName(QString::fromUtf8("vboxLayout4"));
        vboxLayout4->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);

        vboxLayout4->addWidget(label);

        hboxLayout3 = new QHBoxLayout();
        hboxLayout3->setSpacing(6);
        hboxLayout3->setObjectName(QString::fromUtf8("hboxLayout3"));
        hboxLayout3->setContentsMargins(0, 0, 0, 0);
        normalsquality = new QSlider(centralWidget);
        normalsquality->setObjectName(QString::fromUtf8("normalsquality"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(normalsquality->sizePolicy().hasHeightForWidth());
        normalsquality->setSizePolicy(sizePolicy2);
        normalsquality->setMinimum(3);
        normalsquality->setMaximum(32);
        normalsquality->setPageStep(4);
        normalsquality->setValue(3);
        normalsquality->setOrientation(Qt::Vertical);
        normalsquality->setInvertedAppearance(true);
        normalsquality->setTickPosition(QSlider::TicksAbove);

        hboxLayout3->addWidget(normalsquality);

        normalslength = new QSlider(centralWidget);
        normalslength->setObjectName(QString::fromUtf8("normalslength"));
        sizePolicy2.setHeightForWidth(normalslength->sizePolicy().hasHeightForWidth());
        normalslength->setSizePolicy(sizePolicy2);
        normalslength->setMinimum(1);
        normalslength->setMaximum(100);
        normalslength->setPageStep(5);
        normalslength->setValue(8);
        normalslength->setOrientation(Qt::Vertical);
        normalslength->setInvertedAppearance(true);
        normalslength->setTickPosition(QSlider::TicksAbove);

        hboxLayout3->addWidget(normalslength);


        vboxLayout4->addLayout(hboxLayout3);


        vboxLayout2->addLayout(vboxLayout4);


        hboxLayout2->addLayout(vboxLayout2);


        gridLayout->addLayout(hboxLayout2, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);
        QObject::connect(lightingswitch, SIGNAL(toggled(bool)), lighting, SLOT(setEnabled(bool)));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Mesh2", nullptr));
        normButton->setText(QCoreApplication::translate("MainWindow", "Std", nullptr));
        lighting->setText(QCoreApplication::translate("MainWindow", "Lighting", nullptr));
        lightingswitch->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /></head><body style=\" white-space: pre-wrap; font-family:MS Shell Dlg; font-weight:400; font-style:normal; text-decoration:none;\"><p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Polygon Offset</p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /></head><body style=\" white-space: pre-wrap; font-family:MS Shell Dlg; font-weight:400; font-style:normal; text-decoration:none;\"><p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Resolution</p></body></html>", nullptr));
        projection->setText(QCoreApplication::translate("MainWindow", "Ortho", nullptr));
        colorlegend->setText(QCoreApplication::translate("MainWindow", "Legend", nullptr));
        autoscale->setText(QCoreApplication::translate("MainWindow", "Autoscale", nullptr));
        mouseinput->setText(QCoreApplication::translate("MainWindow", "Mouse", nullptr));
        shader->setText(QCoreApplication::translate("MainWindow", "Shading", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /></head><body style=\" white-space: pre-wrap; font-family:MS Shell Dlg; font-weight:400; font-style:normal; text-decoration:none;\"><p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Normals</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MESH2MAINWINDOWBASE4_H
