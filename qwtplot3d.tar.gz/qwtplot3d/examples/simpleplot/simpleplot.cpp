//-----------------------------------------------------------------
//              simpleplot.cpp
//
//      A simple example which shows how to use SurfacePlot
//-----------------------------------------------------------------

#include <math.h>
#include <qapplication.h>
#include <qwt3d_surfaceplot.h>
#include <qwt3d_function.h>
#include "qwt3d_plot.h"
#include "qwt3d_parametricsurface.h"
#include "qwt3d_enrichment_std.h"
#include "../mylineplot3d.h"
#include "simpleplotgui.h"
#include <QFile>
#include <QDebug>
#include <QStringList>
#include <QTimer>


using namespace Qwt3D;

class Rosenbrock : public Function
{
public:

    Rosenbrock(SurfacePlot& pw)
        :Function(pw)
    {
    }
    Rosenbrock(){}
    double operator()(double x, double y)
    {
        //	return 0;
        return x*y/2;
        return x*sin(y)* log(x) + y* cos(x);
        return log(sin(x) * cos(y));
        return log((1-x)*(1-x) + 100 * (y - x*x)*(y - x*x)) / 8;

    }
};

class TestPoint: public ParametricSurface
{
public:
    virtual Qwt3D::Triple operator()(double u, double v);

};

Qwt3D::Triple TestPoint::operator()(double u, double v)
{
    return Qwt3D::Triple(u,v,sqrt(u*u + v*v));
}

class Plot : public SurfacePlot
{
//    Q_OBJECT
public:
    Plot();

    virtual void timerEvent(QTimerEvent *e)
    {
        if (e->timerId() == myTimerId)
        {
//            time_ += 1;
//            if (lineData.empty())
//            {
//                lineData.push_back(Qwt3D::Triple(0,0,0));

//            }
//            else
//            {
//                Qwt3D::Triple t = (*lineData.rbegin());
//                Qwt3D::Triple t2 = (*lineData.rbegin());
//                t += Qwt3D::Triple(rand()%6,rand()%6,rand()%6);

//                lineData.push_back(t);
//                t += Qwt3D::Triple(rand()%6,rand()%6,rand()%6);



//                myLine1->add(t);

//                t2 += Qwt3D::Triple(rand()%6,rand()%6,rand()%6);
//                myLine2->add(t2);
//            }
//            lineData2.push_back(Qwt3D::Triple(lineData[data_i]));
//            if (data_i==0)
//            {
//                myLine1->add(Qwt3D::Triple(lineData[0]));

//            }
            data_i++;
//            myLine1->add(Qwt3D::Triple(lineData[data_i]));
        }

        updateData();
        updateGL();
    }

    virtual void createLines()
    {

        if (!actualData_p)
            return;
        Line3D p;
        p.configure(3,true);

        //todo future work
        if (p.type() != Enrichment::VERTEXENRICHMENT)
            return;

        p.assign(*this);
        p.drawBegin();

        VertexEnrichment* ve = (VertexEnrichment*)&p;


//        for (int i = 0; i < lineData2.size(); i ++)

        if(lineData.size()>0)
        {
            if (lineData[data_i].x > xMax)
            {
                xMax += 100;
            }
            if (lineData[data_i].y > yMax)
            {
                yMax += 100;
            }
            if (lineData[data_i].z > zMax)
            {
                zMax += 100;
            }
            p.draw(lineData[data_i]);
            qDebug()<<data_i;
        }
        p.drawEnd();
    }

    virtual void keyPressEvent(QKeyEvent *)
    {
        setShift(1,0,0);



        setRotation(30,0,15);
        setScale(1,1,1);
        setShift(0.15,0,0);
        setZoom(0.9);
    }

    void readFile();
//private slots:
//    void timeout();

protected:
    int myTimerId;
    std::vector<Qwt3D::Triple> lineData;
    std::vector<Qwt3D::Triple> lineData2;
    int time_;

    double xMax;
    double yMax;
    double zMax;

    Qwt3D::Line3D * myLine1;
    Qwt3D::Line3D * myLine2;

    int data_i=0;

//    QTimer *timer;

};


Plot::Plot()
{
//    timer=new QTimer();
//    timer->setInterval(100);
//    timer->setSingleShot(false);
//    connect(timer,SIGNAL(timeout()),this,SLOT(timeout()));
    time_ = 0;

    xMax = 150;
    yMax = 100;
    zMax = 450;
    //	setFloorStyle(FLOORISO);

    setPlotStyle(Qwt3D::LINE3D_STYLE);

    setTitle("A Simple SurfacePlot Demonstration");
    setIsolines(5);
    Rosenbrock rosenbrock;
    coordinates()->setGridLines(true,true,/*Qwt3D::LEFT|Qwt3D::BACK|*/Qwt3D::FLOOR);
    rosenbrock.setMesh(5,5);
    rosenbrock.setDomain(-100,xMax,-50,yMax);
    rosenbrock.setMinZ(150);
    rosenbrock.setMaxZ(zMax);
    rosenbrock.create(*this);

    Qwt3D::Line3D _l3d;
    myLine1 = dynamic_cast<Qwt3D::Line3D *>(this->addEnrichment(_l3d));
    myLine2 = dynamic_cast<Qwt3D::Line3D *>(this->addEnrichment(_l3d));
    myLine1->configure(3,true);
    myLine1->setLineColor(0,Qwt3D::RGBA(1,0,0,1));
    myLine1->setLineColor(100,Qwt3D::RGBA(0.5,0.6,0.5,1));

    myLine2->configure(1,true);
    myLine2->setLineColor(0,Qwt3D::RGBA(0.5,0.6,0.5,1));
    myLine2->setLineColor(200,Qwt3D::RGBA(0.9,0.3,0.2,1));
    //    TestPoint tp;
    //    tp.setDomain(-10,10,-10,10);
    //    tp.setMesh(5,5);
    //    tp.create(*this);

    setShift(1,0,0);



    setRotation(30,0,15);
    setScale(1,1,1);
    setShift(0.15,0,0);
    setZoom(0.9);
    int axesCount = coordinates()->axes.size();
    for (unsigned i=0; i!=coordinates()->axes.size(); ++i)
    {
        coordinates()->axes[i].setMajors(7);
        coordinates()->axes[i].setMinors(4);
    }



    coordinates()->axes[X1].setLabelString("x");
    coordinates()->axes[Y1].setLabelString("y");
    coordinates()->axes[Z1].setLabelString("z"); // Omega - see http://www.unicode.org/charts/


    setCoordinateStyle(BOX);
    //	Qwt3D::PLOTSTYLE s = plotStyle();




    updateData();
    updateGL();

    readFile();

//    myTimerId = startTimer(1);
//    timerEvent();
    createLines();
    updateData();
    updateGL();
//    timer->start();
}

void Plot::readFile()
{
    QFile file("sphereData_3.txt");
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text))
        qDebug()<<file.errorString();
    else
        qDebug()<<"openok";
    //      file.seek(0);

    QTextStream shuru(&file);
    while(! shuru.atEnd())
    {
        QString line=shuru.readLine();
        QStringList strlist=line.split(" ");

//        qDebug() << strlist;

        double aa=strlist[0].toDouble();
        double bb=strlist[1].toDouble();
        double cc=strlist[2].toDouble();

        Qwt3D::Triple t=Qwt3D::Triple(aa,bb,cc);
        lineData.push_back(t);
        myLine1->add(t);
//        qDebug()<<aa << bb << cc;
    }
    file.close();
}

//void Plot::timeout()
//{
//    data_i++;
//}




int main(int argc, char **argv)
{
    QApplication a(argc, argv);


    //     MyLinePlot3d gui;
    //     gui.show();

    Plot gui;
    gui.show();

    return a.exec();
}
