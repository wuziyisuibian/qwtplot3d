/********************************************************************************
** Form generated from reading UI file 'simpleplotgui.ui'
**
** Created: Thu Dec 29 10:33:23 2016
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIMPLEPLOTGUI_H
#define UI_SIMPLEPLOTGUI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SimplePlotGui
{
public:

    void setupUi(QWidget *SimplePlotGui)
    {
        if (SimplePlotGui->objectName().isEmpty())
            SimplePlotGui->setObjectName(QString::fromUtf8("SimplePlotGui"));
        SimplePlotGui->resize(400, 300);

        retranslateUi(SimplePlotGui);

        QMetaObject::connectSlotsByName(SimplePlotGui);
    } // setupUi

    void retranslateUi(QWidget *SimplePlotGui)
    {
        SimplePlotGui->setWindowTitle(QApplication::translate("SimplePlotGui", "SimplePlotGui", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class SimplePlotGui: public Ui_SimplePlotGui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIMPLEPLOTGUI_H
