#include "simpleplotgui.h"
#include "..\mylineplot3d.h"
#include "QBoxLayout"
#include "qwt3d_enrichment_std.h"

SimplePlotGui::SimplePlotGui(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	myL3d = new MyLinePlot3d();
	QVBoxLayout * qvl = new QVBoxLayout();
	qvl->addWidget(myL3d);
	this->setLayout(qvl);
	myL3d->init();
	myL3d->resize(800,600);
	this->resize(800,600);
	Qwt3D::Line3D l3d;

	mypL3d_1 = dynamic_cast<Qwt3D::Line3D *>(myL3d->addEnrichment(l3d));

	myL3d->init();
	myL3d->coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);

	myL3d->setTitle(QString::fromLocal8Bit("����"));

	mypL3d_1->configure(2,true);
	mypL3d_1->setLineColor(0,Qwt3D::RGBA(1,0,0,1));

	mypL3d_1->setLineColor(100,Qwt3D::RGBA(0,1,0,1));

	mypL3d_1->setLineColor(200,Qwt3D::RGBA(0,0,1,1));

	x = y = 0.0;
	startTimer(50);


}

SimplePlotGui::~SimplePlotGui()
{

}

void SimplePlotGui::timerEvent(QTimerEvent *)
{
	x += rand()%7;
	y += rand()%7;
	z += rand()%7;
	myL3d->setCurMaxMin(0,x,0,y,0,z);
	mypL3d_1->add(Qwt3D::Triple(x,y,z));

	myL3d->tick();

	Sleep(100);
	
}
