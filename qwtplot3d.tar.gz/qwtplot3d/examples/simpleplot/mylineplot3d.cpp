#include "mylineplot3d.h"


#include <math.h>
#include <qapplication.h>
#include <qwt3d_surfaceplot.h>
#include <qwt3d_function.h>
#include "qwt3d_plot.h"
#include "qwt3d_parametricsurface.h"
#include "qwt3d_enrichment_std.h"
#include "QMessageBox"


using namespace Qwt3D;

class Rosenbrock : public Function
{
public:

    Rosenbrock(SurfacePlot& pw)
        :Function(pw)
    {
    }
    Rosenbrock(){}
    double operator()(double x, double y)
    {
        //	return 0;
        return x*y/2;
        return x*sin(y)* log(x) + y* cos(x);
        return log(sin(x) * cos(y));
        return log((1-x)*(1-x) + 100 * (y - x*x)*(y - x*x)) / 8;

    }
};

//class TestPoint: public ParametricSurface
//{
//public:
//     virtual Qwt3D::Triple operator()(double u, double v);

//};

//Qwt3D::Triple TestPoint::operator()(double u, double v)
//{
//    return Qwt3D::Triple(u,v,sqrt(u*u + v*v));
//}


MyLinePlot3d::MyLinePlot3d()
{
    //-----------------line
    Qwt3D::Line3D _l3d;
    myLine1 = dynamic_cast<Qwt3D::Line3D *>(this->addEnrichment(_l3d));
    myLine1->configure(3,true);
    myLine1->setLineColor(0,Qwt3D::RGBA(1,0,0,1));
    myLine1->setLineColor(100,Qwt3D::RGBA(0.5,0.6,0.5,1));
    myLine1->configure(3,true);
    myLine1->setLineColor(0,Qwt3D::RGBA(1,0,0,1));
    myLine1->setLineColor(100,Qwt3D::RGBA(0.5,0.6,0.5,1));

    printf("--------------\n");
    myxMax = 500;
    myyMax = 500;
    myzMax = 500;
    myCurxMax = 500.0;
    myCurxMin = -500.0;
    myCuryMax = 500.0;
    myCuryMin = -500.0;
    myCurzMax = 500.0;
    myCurzMin = -500.0;
    //-----------size
    //	setFloorStyle(FLOORISO);

    setPlotStyle(Qwt3D::LINE3D_STYLE);
    coordinates()->setAutoScale();


    setTitle("A Simple SurfacePlot Demonstration");
    setIsolines(5);
    Rosenbrock rosenbrock;
    coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);
    rosenbrock.setMesh(5,5);

    rosenbrock.setDomain(-500,myxMax,-500,myyMax);
    rosenbrock.setMinZ(-500);
    rosenbrock.setMaxZ(myzMax);//-----------size
    rosenbrock.create(*this);


    // 	TestPoint tp;
    // 	tp.setDomain(-10,10,-10,10);
    // 	tp.setMesh(5,5);
    // 	tp.create(*this);

    setShift(1,0,0);



    setRotation(30,0,15);
    setScale(1,1,1);
    setShift(0.15,0,0);
    setZoom(0.9);
    int axesCount = coordinates()->axes.size();
    for (unsigned i=0; i!=coordinates()->axes.size(); ++i)
    {
        coordinates()->axes[i].setMajors(7);
        coordinates()->axes[i].setMinors(4);
    }



    coordinates()->axes[X1].setLabelString("x-axis");
    coordinates()->axes[Y1].setLabelString("y-axis");
    coordinates()->axes[Z1].setLabelString(QChar(0x38f)); // Omega - see http://www.unicode.org/charts/


    setCoordinateStyle(BOX);
    //	Qwt3D::PLOTSTYLE s = plotStyle();

    myTimerId = startTimer(100);
    updateData();
    updateGL();
}

MyLinePlot3d::~MyLinePlot3d()
{

}

void MyLinePlot3d::init()
{

}

void MyLinePlot3d::createLines()
{
    if (!actualData_p)
        return;
    Line3D p;
    p.configure(3,true);

    //todo future work
    if (p.type() != Enrichment::VERTEXENRICHMENT)
        return;

    p.assign(*this);
    p.drawBegin();

    VertexEnrichment* ve = (VertexEnrichment*)&p;


    for (int i = 0; i < lineData.size(); i ++)
    {
        if (lineData[i].x > myCurxMax)
        {
            myCurxMax += 100;
        }
        if (lineData[i].y > myCuryMax)
        {
            myCuryMax += 100;
        }
        if (lineData[i].z > myCurzMax)
        {
           myCurzMax += 100;
        }
        p.draw(lineData[i]);

    }
    p.drawEnd();
}

void MyLinePlot3d::keyPressEvent(QKeyEvent * e)
{
    int c = e->key();

    if(e->key() == 0x20)
    {
        setShift(1,0,0);
        setRotation(30,0,15);
        setScale(1,1,1);
        setShift(0.15,0,0);
        setZoom(0.9);
    }
    else if(c == 65)
    {
        printf("set scale %f %f %f\n ",xScale(),yScale()*1.2,zScale());
        setScale(1,1,zScale() * 1.2);
    }


}

void MyLinePlot3d::timerEvent(QTimerEvent *e)
{
    if (e->timerId() == myTimerId)
    {
        time_ += 1;
        if (lineData.empty())
        {
            lineData.push_back(Qwt3D::Triple(0,0,0));

        }
        else
        {
            Qwt3D::Triple t = (*lineData.rbegin());
            Qwt3D::Triple t2 = (*lineData.rbegin());
            t += Qwt3D::Triple(rand()%6,rand()%6,rand()%6);

             lineData.push_back(t);
            t += Qwt3D::Triple(rand()%6,rand()%6,rand()%6);



            myLine1->add(t);

            t2 += Qwt3D::Triple(rand()%6,rand()%6,rand()%6);
            myLine2->add(t2);
        }
    }


    updateData();
    updateGL();

}


void MyLinePlot3d::tick()
{
    updateData();
    updateGL();
}

void MyLinePlot3d::setCurMaxMin(double xmin,double xmax,double ymin,double ymax,double zmin,double zmax)
{
    if (xmin < myCurxMin)
    {
        myCurxMin = xmin;
    }
    if (xmax > myCurxMax)
    {
        myCurxMax = xmax;
    }

    if (ymin < myCuryMin)
    {
        myCuryMin = ymin;
    }

    if (ymax > myCuryMax)
    {
        myCuryMax = ymax;
    }

    if (zmin < myCurzMin)
    {
        myCurzMin = zmin;
    }

    if (zmax > myCurzMax)
    {
        myCurzMax = zmax;
    }


    if ((myCurxMax - myxMax) > 1 )
    {
        myxMax += 1000;
        myyMax = myxMax;

        Rosenbrock rosenbrock;
        //coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);
        rosenbrock.setMesh(5,5);
        rosenbrock.setDomain(0,myxMax,0,myyMax);
        rosenbrock.setMinZ(0);
        rosenbrock.setMaxZ(myzMax);
        rosenbrock.create(*this);

        double _yScale = myxMax / myzMax;
        _yScale = (myxMax / myzMax) > _yScale? (myyMax / myzMax): _yScale;
        setScale(1,1,_yScale);

        //	printf("---set scale %f %f %f\n",1,1,_yScale);
        //	QMessageBox::information(NULL," ",QString("%1").arg(QString::number(_yScale)));
    }

    if ((myCuryMax - myyMax) > 1)
    {
        myyMax += 1000;
        myxMax = myyMax;
        Rosenbrock rosenbrock;
        //coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);
        rosenbrock.setMesh(5,5);
        rosenbrock.setDomain(0,myxMax,0,myyMax);
        rosenbrock.setMinZ(0);
        rosenbrock.setMaxZ(myzMax);
        rosenbrock.create(*this);

        double _yScale = myxMax / myzMax;
        _yScale = (myxMax / myzMax) > _yScale? (myyMax / myzMax): _yScale;
        setScale(1,1,_yScale);
        //	printf("----set scale %f %f %f\n",1,1,_yScale);
        //	QMessageBox::information(NULL," ",QString("%1").arg(QString::number(_yScale)));
    }

    if (myCurzMax > myzMax)
    {
        myzMax += 500;

        Rosenbrock rosenbrock;
        //coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);
        rosenbrock.setMesh(5,5);
        rosenbrock.setDomain(0,myxMax,0,myyMax);
        rosenbrock.setMinZ(0);
        rosenbrock.setMaxZ(myzMax);
        rosenbrock.create(*this);


    }
}



