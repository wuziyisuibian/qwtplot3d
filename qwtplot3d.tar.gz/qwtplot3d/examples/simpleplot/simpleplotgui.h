#ifndef SIMPLEPLOTGUI_H
#define SIMPLEPLOTGUI_H

#include <QWidget>
#include "ui_simpleplotgui.h"
class MyLinePlot3d;
namespace Qwt3D
{
	class Line3D;
}

class SimplePlotGui : public QWidget
{
	Q_OBJECT

public:
	SimplePlotGui(QWidget *parent = 0);
	~SimplePlotGui();

	virtual void timerEvent(QTimerEvent *);

private:
	Ui::SimplePlotGui ui;

	 MyLinePlot3d *myL3d;

	 Qwt3D::Line3D * mypL3d_1;

	 double x;
	 double y;
	 double z;

};

#endif // SIMPLEPLOTGUI_H
