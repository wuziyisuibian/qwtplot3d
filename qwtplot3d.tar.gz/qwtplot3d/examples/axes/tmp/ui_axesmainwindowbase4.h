/********************************************************************************
** Form generated from reading UI file 'axesmainwindowbase4.ui'
**
** Created: Wed Oct 26 18:19:58 2016
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AXESMAINWINDOWBASE4_H
#define UI_AXESMAINWINDOWBASE4_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QFrame>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QWidget *widget;
    QVBoxLayout *vboxLayout;
    QHBoxLayout *hboxLayout;
    QFrame *frame;
    QVBoxLayout *vboxLayout1;
    QHBoxLayout *hboxLayout1;
    QLabel *label_4;
    QSpacerItem *spacerItem;
    QHBoxLayout *hboxLayout2;
    QSlider *ticLengthSlider;
    QSlider *ticNumberSlider;
    QHBoxLayout *hboxLayout3;
    QWidget *widget_2;
    QVBoxLayout *vboxLayout2;
    QVBoxLayout *vboxLayout3;
    QLabel *label_2;
    QSlider *numbergapslider;
    QVBoxLayout *vboxLayout4;
    QLabel *label;
    QSlider *labelgapslider;
    QCheckBox *smoothBox;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(694, 600);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(590, 10, 61, 421));
        vboxLayout = new QVBoxLayout(centralWidget);
#ifndef Q_OS_MAC
        vboxLayout->setSpacing(6);
#endif
        vboxLayout->setContentsMargins(8, 8, 8, 8);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        hboxLayout = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout->setSpacing(6);
#endif
#ifndef Q_OS_MAC
        hboxLayout->setContentsMargins(0, 0, 0, 0);
#endif
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        QSizePolicy sizePolicy(static_cast<QSizePolicy::Policy>(7), static_cast<QSizePolicy::Policy>(7));
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Sunken);

        hboxLayout->addWidget(frame);

        vboxLayout1 = new QVBoxLayout();
#ifndef Q_OS_MAC
        vboxLayout1->setSpacing(6);
#endif
        vboxLayout1->setContentsMargins(0, 0, 0, 0);
        vboxLayout1->setObjectName(QString::fromUtf8("vboxLayout1"));
        hboxLayout1 = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout1->setSpacing(6);
#endif
#ifndef Q_OS_MAC
        hboxLayout1->setContentsMargins(0, 0, 0, 0);
#endif
        hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        QSizePolicy sizePolicy1(static_cast<QSizePolicy::Policy>(0), static_cast<QSizePolicy::Policy>(0));
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy1);

        hboxLayout1->addWidget(label_4);

        spacerItem = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        hboxLayout1->addItem(spacerItem);


        vboxLayout1->addLayout(hboxLayout1);

        hboxLayout2 = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout2->setSpacing(6);
#endif
        hboxLayout2->setContentsMargins(0, 0, 0, 0);
        hboxLayout2->setObjectName(QString::fromUtf8("hboxLayout2"));
        ticLengthSlider = new QSlider(centralWidget);
        ticLengthSlider->setObjectName(QString::fromUtf8("ticLengthSlider"));
        QSizePolicy sizePolicy2(static_cast<QSizePolicy::Policy>(0), static_cast<QSizePolicy::Policy>(7));
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(ticLengthSlider->sizePolicy().hasHeightForWidth());
        ticLengthSlider->setSizePolicy(sizePolicy2);
        ticLengthSlider->setMaximum(100);
        ticLengthSlider->setValue(10);
        ticLengthSlider->setOrientation(Qt::Vertical);
        ticLengthSlider->setInvertedAppearance(true);
        ticLengthSlider->setTickPosition(QSlider::TicksBelow);

        hboxLayout2->addWidget(ticLengthSlider);

        ticNumberSlider = new QSlider(centralWidget);
        ticNumberSlider->setObjectName(QString::fromUtf8("ticNumberSlider"));
        sizePolicy2.setHeightForWidth(ticNumberSlider->sizePolicy().hasHeightForWidth());
        ticNumberSlider->setSizePolicy(sizePolicy2);
        ticNumberSlider->setMaximum(25);
        ticNumberSlider->setOrientation(Qt::Vertical);
        ticNumberSlider->setInvertedAppearance(true);
        ticNumberSlider->setTickPosition(QSlider::TicksBelow);

        hboxLayout2->addWidget(ticNumberSlider);


        vboxLayout1->addLayout(hboxLayout2);


        hboxLayout->addLayout(vboxLayout1);


        vboxLayout->addLayout(hboxLayout);

        hboxLayout3 = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout3->setSpacing(6);
#endif
        hboxLayout3->setContentsMargins(0, 0, 0, 0);
        hboxLayout3->setObjectName(QString::fromUtf8("hboxLayout3"));
        widget_2 = new QWidget(centralWidget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        vboxLayout2 = new QVBoxLayout(widget_2);
#ifndef Q_OS_MAC
        vboxLayout2->setSpacing(6);
#endif
        vboxLayout2->setContentsMargins(0, 0, 0, 0);
        vboxLayout2->setObjectName(QString::fromUtf8("vboxLayout2"));
        vboxLayout2->setContentsMargins(0, 0, 0, 0);
        vboxLayout3 = new QVBoxLayout();
#ifndef Q_OS_MAC
        vboxLayout3->setSpacing(6);
#endif
#ifndef Q_OS_MAC
        vboxLayout3->setContentsMargins(0, 0, 0, 0);
#endif
        vboxLayout3->setObjectName(QString::fromUtf8("vboxLayout3"));
        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        vboxLayout3->addWidget(label_2);

        numbergapslider = new QSlider(widget_2);
        numbergapslider->setObjectName(QString::fromUtf8("numbergapslider"));
        QSizePolicy sizePolicy3(static_cast<QSizePolicy::Policy>(7), static_cast<QSizePolicy::Policy>(5));
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(numbergapslider->sizePolicy().hasHeightForWidth());
        numbergapslider->setSizePolicy(sizePolicy3);
        numbergapslider->setMaximum(10);
        numbergapslider->setOrientation(Qt::Horizontal);
        numbergapslider->setTickPosition(QSlider::TicksAbove);

        vboxLayout3->addWidget(numbergapslider);


        vboxLayout2->addLayout(vboxLayout3);

        vboxLayout4 = new QVBoxLayout();
#ifndef Q_OS_MAC
        vboxLayout4->setSpacing(6);
#endif
        vboxLayout4->setContentsMargins(0, 0, 0, 0);
        vboxLayout4->setObjectName(QString::fromUtf8("vboxLayout4"));
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));

        vboxLayout4->addWidget(label);

        labelgapslider = new QSlider(widget_2);
        labelgapslider->setObjectName(QString::fromUtf8("labelgapslider"));
        sizePolicy3.setHeightForWidth(labelgapslider->sizePolicy().hasHeightForWidth());
        labelgapslider->setSizePolicy(sizePolicy3);
        labelgapslider->setMaximum(10);
        labelgapslider->setOrientation(Qt::Horizontal);
        labelgapslider->setTickPosition(QSlider::TicksAbove);

        vboxLayout4->addWidget(labelgapslider);


        vboxLayout2->addLayout(vboxLayout4);


        hboxLayout3->addWidget(widget_2);

        smoothBox = new QCheckBox(centralWidget);
        smoothBox->setObjectName(QString::fromUtf8("smoothBox"));
        QSizePolicy sizePolicy4(static_cast<QSizePolicy::Policy>(1), static_cast<QSizePolicy::Policy>(5));
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(smoothBox->sizePolicy().hasHeightForWidth());
        smoothBox->setSizePolicy(sizePolicy4);

        hboxLayout3->addWidget(smoothBox);


        vboxLayout->addLayout(hboxLayout3);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /></head><body style=\" white-space: pre-wrap; font-family:MS Shell Dlg; font-weight:400; font-style:normal; text-decoration:none;\"><p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Tics</p></body></html>", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /></head><body style=\" white-space: pre-wrap; font-family:MS Shell Dlg; font-weight:400; font-style:normal; text-decoration:none;\"><p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Number gap</p></body></html>", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /></head><body style=\" white-space: pre-wrap; font-family:MS Shell Dlg; font-weight:400; font-style:normal; text-decoration:none;\"><p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Label gap</p></body></html>", 0, QApplication::UnicodeUTF8));
        smoothBox->setText(QApplication::translate("MainWindow", "Smooth Lines", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AXESMAINWINDOWBASE4_H
