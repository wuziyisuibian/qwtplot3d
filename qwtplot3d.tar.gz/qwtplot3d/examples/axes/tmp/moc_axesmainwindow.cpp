/****************************************************************************
** Meta object code from reading C++ file 'axesmainwindow.h'
**
** Created: Wed Oct 26 18:19:58 2016
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/axesmainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'axesmainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_AxesMainWindow[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   16,   15,   15, 0x0a,
      38,   16,   15,   15, 0x0a,
      55,   15,   15,   15, 0x0a,
      80,   76,   15,   15, 0x0a,
     105,   98,   15,   15, 0x0a,
     123,   15,   15,   15, 0x0a,
     139,   15,   15,   15, 0x0a,
     154,   15,   15,   15, 0x0a,
     168,   15,   15,   15, 0x0a,
     180,   15,   15,   15, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_AxesMainWindow[] = {
    "AxesMainWindow\0\0gap\0setNumberGap(int)\0"
    "setLabelGap(int)\0setSmoothLines(bool)\0"
    "val\0setTicLength(int)\0degree\0"
    "setTicNumber(int)\0standardItems()\0"
    "complexItems()\0letterItems()\0timeItems()\0"
    "customScale()\0"
};

const QMetaObject AxesMainWindow::staticMetaObject = {
    { &DummyBase::staticMetaObject, qt_meta_stringdata_AxesMainWindow,
      qt_meta_data_AxesMainWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AxesMainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AxesMainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AxesMainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AxesMainWindow))
        return static_cast<void*>(const_cast< AxesMainWindow*>(this));
    return DummyBase::qt_metacast(_clname);
}

int AxesMainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = DummyBase::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: setNumberGap((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: setLabelGap((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: setSmoothLines((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: setTicLength((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: setTicNumber((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: standardItems(); break;
        case 6: complexItems(); break;
        case 7: letterItems(); break;
        case 8: timeItems(); break;
        case 9: customScale(); break;
        default: ;
        }
        _id -= 10;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
