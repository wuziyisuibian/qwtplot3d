<!DOCTYPE TS><TS>
<context>
    <name>NativeReader</name>
    <message>
        <source>NativeReader::read: cannot open data file &quot;%s&quot;
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
