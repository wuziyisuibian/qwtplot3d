#ifndef MYLINEPLOT3D_H
#define MYLINEPLOT3D_H

#include"qwt3d_surfaceplot.h"
#include "qwt3d_global.h"
class QWidget;


class QWT3D_EXPORT  MyLinePlot3d : public Qwt3D::SurfacePlot
{
	Q_OBJECT

public:
	MyLinePlot3d();
	~MyLinePlot3d();

	virtual void init();

	virtual void createLines();

	virtual void keyPressEvent(QKeyEvent *);
	
	virtual void tick();
	virtual void setCurMaxMin(double xmin,double xmax,double ymin,double ymax,double zmin,double zmax);

private:
	int myTimerId;

	int time_;

	double myxMax;
	double myyMax;
	double myzMax;

	double myCurxMin;
	double myCuryMin;
	double myCurzMin;
	double myCurxMax;
	double myCuryMax;
	double myCurzMax;
};

#endif // MYLINEPLOT3D_H
