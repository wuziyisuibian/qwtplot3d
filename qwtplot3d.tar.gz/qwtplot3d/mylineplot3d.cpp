#include "mylineplot3d.h"


#include <math.h>
#include <qapplication.h>
#include <qwt3d_surfaceplot.h>
#include <qwt3d_function.h>
#include "qwt3d_plot.h"
#include "qwt3d_parametricsurface.h"
#include "qwt3d_enrichment_std.h"
#include "QMessageBox"


using namespace Qwt3D;

class Rosenbrock : public Function
{
public:

	Rosenbrock(SurfacePlot& pw)
		:Function(pw)
	{
	}
	Rosenbrock(){}
	double operator()(double x, double y)
	{
		//	return 0;
		return x*y/2;
		return x*sin(y)* log(x) + y* cos(x);
		return log(sin(x) * cos(y));
		return log((1-x)*(1-x) + 100 * (y - x*x)*(y - x*x)) / 8;

	}
};


MyLinePlot3d::MyLinePlot3d()
{
	printf("--------------\n");
	myxMax = 1000;
	myyMax = 1000;
	myzMax = 1000;

	myCurxMax = 0.0;
	myCurxMin = 0.0;
	myCuryMax = 0.0;
	myCuryMin = 0.0;
	myCurzMax = 0.0;
	myCurzMin = 0.0;
	//	setFloorStyle(FLOORISO);

	setPlotStyle(Qwt3D::LINE3D_STYLE);
	coordinates()->setAutoScale();


	setTitle("A Simple SurfacePlot Demonstration");
	setIsolines(5);
	Rosenbrock rosenbrock;
	coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);
	rosenbrock.setMesh(5,5);
	rosenbrock.setDomain(0,myxMax,0,myyMax);
	rosenbrock.setMinZ(0);
	rosenbrock.setMaxZ(myzMax);
	rosenbrock.create(*this);

	
	// 	TestPoint tp;
	// 	tp.setDomain(-10,10,-10,10);
	// 	tp.setMesh(5,5);
	// 	tp.create(*this);

	setShift(1,0,0);



	setRotation(30,0,15);
	setScale(1,1,1);
	setShift(0.15,0,0);
	setZoom(0.9);
	int axesCount = coordinates()->axes.size();
	for (unsigned i=0; i!=coordinates()->axes.size(); ++i)
	{
		coordinates()->axes[i].setMajors(7);
		coordinates()->axes[i].setMinors(4);
	}



	coordinates()->axes[X1].setLabelString("x-axis");
	coordinates()->axes[Y1].setLabelString("y-axis");
	coordinates()->axes[Z1].setLabelString(QChar(0x38f)); // Omega - see http://www.unicode.org/charts/


	setCoordinateStyle(BOX);
	//	Qwt3D::PLOTSTYLE s = plotStyle();

	

	updateData();
	updateGL();
}

MyLinePlot3d::~MyLinePlot3d()
{

}

void MyLinePlot3d::init()
{

}

void MyLinePlot3d::createLines()
{
	
}

void MyLinePlot3d::keyPressEvent(QKeyEvent * e)
{
	int c = e->key();

	if(e->key() == 0x20)
	{
		setShift(1,0,0);
		setRotation(30,0,15);
		setScale(1,1,1);
		setShift(0.15,0,0);
		setZoom(0.9);
	}
	else if(c == 65)
	{
		printf("set scale %f %f %f\n ",xScale(),yScale()*1.2,zScale());
		setScale(1,1,zScale() * 1.2);
	}
	
	
}

void MyLinePlot3d::tick()
{
	updateData();
	updateGL();
}

void MyLinePlot3d::setCurMaxMin(double xmin,double xmax,double ymin,double ymax,double zmin,double zmax)
{
	if (xmin < myCurxMin)
	{
		myCurxMin = xmin;
	}
	if (xmax > myCurxMax)
	{
		myCurxMax = xmax;
	}

	if (ymin < myCuryMin)
	{
		myCuryMin = ymin;
	}

	if (ymax > myCuryMax)
	{
		myCuryMax = ymax;
	}

	if (zmin < myCurzMin)
	{
		myCurzMin = zmin;
	}

	if (zmax > myCurzMax)
	{
		myCurzMax = zmax;
	}


	if ((myCurxMax - myxMax) > 1 )
	{
		myxMax += 1000;
		myyMax = myxMax;

		Rosenbrock rosenbrock;
		//coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);
		rosenbrock.setMesh(5,5);
		rosenbrock.setDomain(0,myxMax,0,myyMax);
		rosenbrock.setMinZ(0);
		rosenbrock.setMaxZ(myzMax);
		rosenbrock.create(*this);

		double _yScale = myxMax / myzMax;
		_yScale = (myxMax / myzMax) > _yScale? (myyMax / myzMax): _yScale;
		setScale(1,1,_yScale);

	//	printf("---set scale %f %f %f\n",1,1,_yScale);
	//	QMessageBox::information(NULL," ",QString("%1").arg(QString::number(_yScale)));
	}

	if ((myCuryMax - myyMax) > 1)
	{
		myyMax += 1000;
		myxMax = myyMax;
		Rosenbrock rosenbrock;
		//coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);
		rosenbrock.setMesh(5,5);
		rosenbrock.setDomain(0,myxMax,0,myyMax);
		rosenbrock.setMinZ(0);
		rosenbrock.setMaxZ(myzMax);
		rosenbrock.create(*this);

		double _yScale = myxMax / myzMax;
		_yScale = (myxMax / myzMax) > _yScale? (myyMax / myzMax): _yScale;
		setScale(1,1,_yScale);
	//	printf("----set scale %f %f %f\n",1,1,_yScale);
	//	QMessageBox::information(NULL," ",QString("%1").arg(QString::number(_yScale)));

		

	}

	if (myCurzMax > myzMax)
	{
		myzMax += 500;
		
		Rosenbrock rosenbrock;
		//coordinates()->setGridLines(true,true,Qwt3D::LEFT|Qwt3D::BACK|Qwt3D::FLOOR);
		rosenbrock.setMesh(5,5);
		rosenbrock.setDomain(0,myxMax,0,myyMax);
		rosenbrock.setMinZ(0);
		rosenbrock.setMaxZ(myzMax);
		rosenbrock.create(*this);
		

	}
}



