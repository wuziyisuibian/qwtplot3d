/****************************************************************************
** Meta object code from reading C++ file 'mylineplot3d.h'
**
** Created: Thu Dec 29 10:12:30 2016
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mylineplot3d.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mylineplot3d.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MyLinePlot3d[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_MyLinePlot3d[] = {
    "MyLinePlot3d\0"
};

const QMetaObject MyLinePlot3d::staticMetaObject = {
    { &Qwt3D::SurfacePlot::staticMetaObject, qt_meta_stringdata_MyLinePlot3d,
      qt_meta_data_MyLinePlot3d, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyLinePlot3d::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyLinePlot3d::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyLinePlot3d::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyLinePlot3d))
        return static_cast<void*>(const_cast< MyLinePlot3d*>(this));
    typedef Qwt3D::SurfacePlot QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int MyLinePlot3d::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef Qwt3D::SurfacePlot QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE
